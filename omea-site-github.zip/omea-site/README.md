# OMÉA Wellness Website
Initial GitHub version for Firebase deployment.